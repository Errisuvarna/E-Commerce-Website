<?php include 'con1.php'; ?>
<!DOCTYPE html>

<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title>Navigation Menu</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
    }

    
    nav {
        display: flex;
        height: 80px;
        width: 100%;
  background: #3e2093;
        
        align-items: center;
        justify-content: space-between;
        padding: 0 50px 0 100px;
        flex-wrap: wrap;
        position: relative; /* Add position relative to the nav container */
    }

    
    .logo {
        display: flex;
        align-items: center;
        color: #fff;
    }

    .logo img {
        width: 150px; /* Adjust the width of the logo image as needed */
        height: 70px;
        margin-right: 0px;
        padding-left: 0%;

    }

    nav ul {
        display: flex;
        flex-wrap: wrap;
        list-style: none;
    }

    

    nav ul {
        display: flex;
        flex-wrap: wrap;
        list-style: none;
    }
    nav ul li {
        margin: 0 5px;
    }
    nav ul li a {
        color: #f2f2f2;
        text-decoration: none;
        font-size: 18px;
        font-weight: 500;
        padding: 8px 15px;
        border-radius: 5px;
        letter-spacing: 1px;
        transition: all 0.3s ease;
        position: relative; /* Add position relative to the list item */
    }
    nav ul li a.active,
    nav ul li a:hover {
        color: #2c7bfe;
        background: #fff;
        z-index: 1; /* Bring the active list item on top of the background */
    }

    nav .menu-btn i {
        color: #fff;
        font-size: 22px;
        cursor: pointer;
        display: none;
    }

    input[type="checkbox"] {
        display: none;
    }

    
    @media (max-width: 920px) {
        nav {
            padding: 0 40px 0 50px;
        }
        nav .menu-btn i {
            display: block;
        }
        #click:checked ~ .menu-btn i:before {
            content: "\f00d";
        }

        nav ul {
            position: fixed;
            top: 80px;
            left: -100%;
            background: #111;
            height: 100vh;
            width: 100%;
            text-align: center;
            display: block;
            transition: all 0.3s ease;
            z-index: 1; /* Bring the menu on top of the image */
        }
        #click:checked ~ ul {
            left: 0;
        }

        nav ul li {
            width: 100%;
            margin: 40px 0;
        }

        nav ul li a {
            width: 100%;
            margin-left: -100%;
            display: block;
            font-size: 20px;
            transition: 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }

        #click:checked ~ ul li a {
            margin-left: 0px;
        }

        nav ul li a.active,
        nav ul li a:hover {
            background: none;
            color: cyan;
        }
    }

   

    .hero-section {
        background-image: url(Home.jpg);
        background-size:cover;

        background-repeat:no-repeat ; /* Adjust the background size to cover the entire container */
        background-position: center;
        height:1000px;
        display: flex;
        align-items: top;
        justify-content: center;
        color:yellow; /* Change the text color to black */
        text-align: center; /* Adjust text alignment */
        padding-left: 20px; /* Add left padding for spacing */
        filter: brightness(90%);
    }

    .hero-text {
        font-size: 20px;
        font-weight: bold;
    }
/* Normal styles for the feature boxes */
#feature {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    padding: 30px 0;
}

.fe-box {
    text-align: center;
    margin-bottom: 20px;
    flex-basis: calc(10% - 20px); 
    padding: 40px;
}

.fe-box img {
    width: 80px;
  height: 80px;
  margin-bottom: 10px;
}

/* Styles for medium screens */
@media (max-width: 768px) {
    .fe-box {
        flex-basis: calc(50% - 20px); /* Each feature box takes up 50% of the container width with 20px margin between them */
    }
}

/* Styles for small screens */
@media (max-width: 480px) {
    .fe-box {
        flex-basis: 100%; /* Each feature box takes up the full width of the container */
    }
}
h1{
    font-size: 50px;
    font-style:italic;
    padding-right: 80px;
    color:yellow;
}



</style>
<body>
<nav>
    <div class="logo"> <img src="logo.jpg"></div>
    <input type="checkbox" id="click">
    <label for="click" class="menu-btn">
        <i class="fas fa-bars"></i>
    </label>
    <ul>
    <li><a href="home1.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="cont1.php">Contact</a></li>
        <li><a href="Team.php">Team</a></li>
        <li><a href="prod.php">Shop</a></li>
        <li><a href="prof.php">My profile</a></li>
        
        
    </ul>
</nav>
<section class="hero-section">
    <div class="hero-text">
    <h3></h3>
        <h1>Handloom Home</h1>
        <h1>Newly Launched</h1>
        
        
    </div>
</section>
<section id="feature" class="section-p1">
        <div class="fe-box">
            <img src="f1.png" alt="">
            <h6>Free Shipping</h6>
        </div>
        <div class="fe-box">
            <img src="f2.png" alt="">
            <h6>Online Order</h6>
        </div>
        <div class="fe-box">
            <img src="f3.png" alt="">
            <h6>Save Money</h6>
        </div>
        <div class="fe-box">
            <img src="f4.png" alt="">
            <h6>Promotions</h6>
        </div>
        <div class="fe-box">
            <img src="f5.png" alt="">
            <h6>Happy Sell</h6>
        </div>
        <div class="fe-box">
            <img src="f6.png" alt="">
            <h6>F24/7 Support</h6>
        </div>
    </section>

</body>
</html>



