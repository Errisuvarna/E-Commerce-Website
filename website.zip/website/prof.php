<?php include 'navbar1.php'; ?>
<!DOCTYPE html>
<html>

<head>
    <script src="cart.js"></script>
    <!-- Include the Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <title>Profile</title>
    <style>
        body {
    font-family: Arial, sans-serif;
  }
  
  .container {
    width: 400px;
    margin: 50px auto;
    text-align: center;
  }
  
  .title {
    font-size: 24px;
    font-weight: bold;
    margin-bottom: 20px;
  }
  
  .profile-card {
    border: 1px solid #ccc;
    border-radius: 5px;
    padding: 20px;
    background-color: #f9f9f9;
  }
  
  .profile-card h3 {
    font-size: 18px;
    margin-bottom: 10px;
  }
  
  .profile-card p {
    margin-bottom: 20px;
  }
  
  .profile-card a {
    display: inline-block;
    padding: 10px 20px;
    background-color: #4CAF50;
    color: #fff;
    text-decoration: none;
    border-radius: 4px;
  }
  
  .profile-card a:hover {
    background-color: #45a049;
  }
    </style>
</head>

<body>
    <div class="container">
        <div class="profile-card">
            <h3>Welcome, User!</h3>
            <p>Here is your profile information.</p>
            
            <a href="order.php">Order</a>
            <!-- <button type="submit" name="signout">Sign Out</button> -->
            <form>
           <a href="index.php">Sign Out</a>
</form>
            <!-- <button type="submit" name="signout">Sign Out</button> -->
        </div>
    </div>
</body>

</html>