<?php
 include 'con1.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>Sign Up</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-image: linear-gradient(rgba(0,0,50,0.8),rgba(0,0,50,0.8)),url(background5.png);
      background-size: cover;
      background-position: center;
      position: relative;
    }
    
    .container {
      width: 400px;
      margin:0 auto;
      padding: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
      text-align: center;
      margin-top: 20vh;
    }
    
    .container h2 {
      text-align: center;
      color: white;
    }
    
    .container input[type="text"],
    .container input[type="email"],
    .container input[type="password"] {
      width: 100%;
      padding-bottom: 10px;
      padding-right: 6px;
      margin-bottom: 10px;
      
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    
    .container button {
      width: 100%;
      padding: 10px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    
    .container button:hover {
      background-color: #45a049;
    }
    
    .container p {
      text-align: center;
      color:white;
      margin-top: 10px;
    }
    .container a{
      color: white;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Sign Up</h2>
    <form method="post">
      <input type="text" name="username" placeholder="Username" required>
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit" name="signup">Sign Up</button>
    </form>
    <p>Already have an account? <a href="index1.php">Sign In</a></p>
  </div>
</body>
</html>