<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "go to cart";
$errors = array();

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['signup'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "INSERT INTO `tables` (name, email, password) VALUES ('$username', '$email', '$password')";
    $result = mysqli_query($conn, $sql);
    if ($result) {
        header('location: index1.php');
        exit;
    } else {
        die("Error: " . mysqli_error($conn));
    }
}

if (isset($_POST['signin'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    if (empty($email) || empty($password)) {
        $errors['signin'] = "Invalid username or password";
    } else {
        $sql = "SELECT * FROM `tables` WHERE email = '$email' AND password = '$password'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) == 1) {
            header('location: home1.php');
            exit;
        } else {
            $errors['signin'] = "Invalid username or password";
        }
    }
}
?>