<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Page</title>
</head>
<style>
    body {
        background-color: #E3E7E8;
        font-family: system-ui;
    }

    .container {
        width: 1000px;
        margin: auto;
        transition: 0.5s;
    }

    .order-details {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        column-gap: 20px;
        row-gap: 20px;
        margin-top: 50px;
    }

    .order-details .item {
        text-align: center;
        background-color: #DCE0E1;
        padding: 20px;
        box-shadow: 0 50px 50px #757676;
        letter-spacing: 1px;
    }

    .order-details .item img {
        width: 90%;
        height: 430px;
        object-fit: cover;
    }

    .order-details .item .title {
        font-weight: 600;
    }

    .order-details .item .price {
        margin: 10px;
    }

    .order-details .item button {
        background-color: #1C1F25;
        color: #fff;
        width: 100%;
        padding: 10px;
    }
</style>
<body>
    <div class="container">
        <h1>Your Order</h1>
        <div class="order-details">
            <!-- JavaScript code in the Shop page will automatically add the products here -->
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const orderDetailsDiv = document.querySelector('.order-details');

            // Extract products from the form data
            const formData = new FormData(document.forms[0]);
            for (const [key, value] of formData.entries()) {
                if (key.startsWith('product_')) {
                    const productData = JSON.parse(value);
                    const productDiv = document.createElement('div');
                    productDiv.classList.add('item');
                    productDiv.innerHTML = `
                        <img src="image/${productData.image}" alt="${productData.name}">
                        <div class="title">${productData.name}</div>
                        <div class="price">$${productData.price.toLocaleString()}</div>
                    `;
                    orderDetailsDiv.appendChild(productDiv);
                }
            }
        });
    </script>
</body>
</html>
