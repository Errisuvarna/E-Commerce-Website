<?php include 'navbar1.php'; ?>
<!DOCTYPE html>

<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
 <title> About</title>
  
</head>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}
.about-us{
  height: 100vh;
  width: 100%;
  padding: 90px 0;
  
  font-size: 30px;
  
}
.pic{
  height: auto;
  width:  302px;
}
.about{
  width: 1130px;
  max-width: 85%;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-around;
}
.text{
  width: 540px;
}
.text h2{
  font-size: 30px;
  font-weight: 600;
  margin-bottom: 10px;
  color: #3e2093;

}
.text h5{
  font-size: 22px;
  font-weight: 500;
  margin-bottom: 20px;
}
span{
  color: #4070f4;
}
.text p{
  font-size: 18px;
  line-height: 25px;
  letter-spacing: 1px;
}
.data{
  margin-top: 30px;
}
.Read{
  font-size: 18px;
  background: #4070f4;
  color: #3e2093;
  text-decoration: none;
  border: none;
  padding: 8px 25px;
  border-radius: 6px;
  transition: 0.5s;
}
.Read:hover{
  background: #000;
  border: 1px solid #4070f4;
}
</style>
<body>
  <section class="about-us">
    <div class="about">
      <img src="abt.webp" class="pic">
      <div class="text">
        <h2>About Us</h2>
        <h5>We Build Greater Futures Through Innovation And Creative Website Or Application!</h5>
        <ul>
        <p>Preserving Tradition: We work closely with skilled artisans to promote traditional handloom techniques, ensuring their preservation for future generations.
        Sustainability: We believe in sustainable fashion practices by using natural fibers, promoting fair trade, and supporting eco-friendly production.
        Empowering Artisans: We strive to empower local weavers and artisans by providing them with fair wages, dignified working conditions, and opportunities to showcase their craft.
        Celebrating Diversity: We take pride in the diverse range of handloom textiles we offer, representing different regions, weaving styles, and cultural expressions.</p>
    </ul>
        <div class="data">
        <a href="#" class="Read">Read more</a>
        </div>
      </div>
    </div>
  </section>
</body>
</html>