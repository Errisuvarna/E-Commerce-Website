
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <title> Contact </title>

    </head>
    <style>
       
        .container{
            padding-top: 50px;
            
        }
        
        form{
            background:white;
            display:flex;
            flex-direction:column;
            padding:5%;
            width:103%;
            
            border-radius:30px;
        
        }
        form h3{
            color:#555;
            font-weight:800;
            margin-bottom:20px;

        }
        form input,form textarea{
            border:0;
            margin:10px 0;
            padding:20px;
            outline:none;
            background:#f5f5f5;
            font-size: 16px;
            border-radius: 30px;
        }
        form button{
            padding:15px;
            background-color:#ff5361;
            color:#fff;
            font-size: 18px;
            border:0;
            outline:none;
            cursor:pointer;
            width:150px;
            margin:20px auto 0;
            border-radius: 30px;
        }
        .right-side .input-box textarea {
  padding-top: 20px;/* Adjust the padding value to reduce the space between textareas */
}

        </style>
    <body>
        <div class="container">
        <h3> order now</h3>
            <form action="https://formsubmit.co/annakavya15@gmail.com" method="POST">
             
                
                <input type="text" name="name" placeholder="Your name" required>
                 
                
                <input type="email" name="email" placeholder="Email Address">
                
                <input type="text" name="phone no." placeholder="Phone no." required>
                
                <textarea name="Address" rows="3" placeholder="address"></textarea> 
                
                <textarea name="products" rows="3" placeholder="products"></textarea> 
               
                <button type="submit"> Send</button>
                
            </form>


        </div>
        
    </body>
</html>
